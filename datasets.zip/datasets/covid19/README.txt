Dataset curated by Dr. Joseph Cohen and Adrien Rosenbrock
